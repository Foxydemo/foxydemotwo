<?php
do_shortcode('[testing]');
?>