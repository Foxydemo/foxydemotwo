<?php 
//echo "h1";
echo do_shortcode('[get_detail]');
?>