<?php 
/** 
 * @package CustomPlugin
 */
/*
Plugin Name: Foxy webhook listener solari
Plugin URI: http://webhook-plugin.com
Description: This is the custom plugin
Version: 1.0.0
Author: Kode Tiger
Author URI: http://webhook-plugin.com
License: GPLv2 or later
Text Domain: webhook-plugin
*/ 

// Exit if accessed directly
if(!defined('ABSPATH')){
    exit;
  }
  
  define("PLUGIN_DIR_PATH", plugin_dir_path(__FILE__));
  define("PLUGIN_URL", plugins_url());
  
  function my_custom_url_handler() {
   
    $uriFound = strpos($_SERVER["REQUEST_URI"], "webhook_add_code.php");
   
     if($uriFound !== false) {
  
        include strtok(strstr($_SERVER["REQUEST_URI"], "webhook_add_code.php"), "?");
        exit();  
     }
     
  }
  function api_calling(){
          global $wpdb;
          $ch = curl_init();
          $curlConfig = array(
          CURLOPT_URL            => "https://api.foxycart.com/token",
          CURLOPT_POST           => true,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_POSTFIELDS     => array(
              'grant_type' => 'refresh_token',
              'refresh_token' => 'vvKk3uc3lhjkyX6U1vWLqK4BJECnhwJIbUavpnKS',
              'client_id' => 'client_luHCLP8quvd2byd1HstU',
              'client_secret' => 'svw6fAbP7W765whGqiEui1BZmdpWDY7Uvz7mqMNQ',
          )
      );
    curl_setopt_array($ch, $curlConfig);
    $result = curl_exec($ch);
    curl_close($ch);
    //var_dump($result);
    //echo "<pre>";
    //print_r($result);
    $parseResult = json_decode($result);
    //echo "<pre>";
    //print_r($parseResult->access_token);
    $accessToken = $parseResult->access_token;
    //die();
    // Store Api Link
        $url = "https://api.foxycart.com";



        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        
        
        
        $headers = array(
        "FOXY-API-VERSION: 1",
        "Authorization: Bearer ".$accessToken,
        );
        //print_r($headers);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        //for debug only!
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        
        
        
        $resp = curl_exec($curl);
        curl_close($curl);
        $parseResp = json_decode($resp);
        $storeDetails = $parseResp->_links;
        //$store_fx = $storeDetails;
        $store = "fx:store";
        //echo "<pre>";
        $store_fx = $storeDetails->$store;
        $store_link = $store_fx->href;
        //echo "<pre>";
        //print_r($store_link);
       // store link
        $url_store = $store_link;
        $curl_store = curl_init($url_store);
        curl_setopt($curl_store, CURLOPT_URL, $url_store);
        curl_setopt($curl_store, CURLOPT_RETURNTRANSFER, true);
      
        //print_r($headers);
        curl_setopt($curl_store, CURLOPT_HTTPHEADER, $headers);
        //for debug only!
        curl_setopt($curl_store, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl_store, CURLOPT_SSL_VERIFYPEER, false);
        
        
        
        $resp_store = curl_exec($curl_store);
        curl_close($curl_store);

        $result_store = json_decode($resp_store);
        $transcation_name = "fx:transactions";
        $transcationUrlList = $result_store->_links;
        $transcation_link = $transcationUrlList->$transcation_name;
        $transcation_url = $transcation_link->href;

        //transcation
        $trans_url = $transcation_url;
        $NewDate=Date('Y-m-d', strtotime('-2 days'));
        $currentDate = date('Y-m-d',strtotime('+1 days'));
        $transcationDate = $NewDate . '..' . $currentDate;
        $urlA = $trans_url;
        $dataArray = ['transaction_date' => $transcationDate];
        
        $data = http_build_query($dataArray);
  
        $getUrl = $urlA."?".$data;

        $curl_trans = curl_init($getUrl);
  
        curl_setopt($curl_trans, CURLOPT_URL, $getUrl);
        curl_setopt($curl_trans, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($curl_trans, CURLOPT_HTTPHEADER, $headers);
        //for debug only!
        curl_setopt($curl_trans, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl_trans, CURLOPT_SSL_VERIFYPEER, false);
        
        
        $resp_cust = curl_exec($curl_trans);
        curl_close($curl_trans);

        $parseCust = json_decode($resp_cust);
        
        $cust = "fx:transactions";
        $allCustDetails = $parseCust->_embedded->$cust;
        foreach($allCustDetails as $key){
        // echo "<pre>";
        // print_r($key->customer_email);
         $customerEmail [] = $key->customer_email;
        }  
        
        $all_users = get_users();
      
        foreach ($all_users as $user) {
    
            $email [] = $user -> user_email ;
    
          }
          // echo "<pre>";
          // print_r($email);
          for($i=0;$i<=(count($customerEmail)-1);$i++){
            // echo "<pre>";
            // print_r($customerEmail[$i]);
            //$j=0;
            for($j=0;$j<=(count($email)-1);$j++){
              // echo "<pre>";
              //   print_r($email[$j]);
              if($customerEmail[$i]!=$email[$j]){
                // echo "<pre>";
                // print_r($customerEmail[$i]);
                // $getEmail = "";
                // $getEmail = $key[i];
               //customer
                  $url_customer = $store_link;
                  $curl_customer = curl_init($url_customer);
                  curl_setopt($curl_customer, CURLOPT_URL, $url_customer);
                  curl_setopt($curl_customer, CURLOPT_RETURNTRANSFER, true);
                
                  //print_r($headers);
                  curl_setopt($curl_customer, CURLOPT_HTTPHEADER, $headers);
                  //for debug only!
                  curl_setopt($curl_customer, CURLOPT_SSL_VERIFYHOST, false);
                  curl_setopt($curl_customer, CURLOPT_SSL_VERIFYPEER, false);
                  
                  $resp_customer = curl_exec($curl_customer);
                  curl_close($curl_customer);
                  $result_customer = json_decode($resp_customer);
                  $customer_name = "fx:customers";
                  $customerUrl = $result_customer->_links->$customer_name->href;
                  $paramurl = $customerUrl;
                  //for does't match email
                  $paramEmail = ['email' => $customerEmail[$i]];
        
                  $dataEmail = http_build_query($paramEmail);
            
                  $getParamUrl = $paramurl."?".$dataEmail;
                  //  echo "<pre>";
                  //  print_r($getParamUrl);
                  $curl_customerDetails = curl_init($getParamUrl);
                  curl_setopt($curl_customerDetails, CURLOPT_URL, $getParamUrl);
                  curl_setopt($curl_customerDetails, CURLOPT_RETURNTRANSFER, true);
                
                  //print_r($headers);
                  curl_setopt($curl_customerDetails, CURLOPT_HTTPHEADER, $headers);
                  //for debug only!
                  curl_setopt($curl_customerDetails, CURLOPT_SSL_VERIFYHOST, false);
                  curl_setopt($curl_customerDetails, CURLOPT_SSL_VERIFYPEER, false);
                  
                  $response_customer = curl_exec($curl_customerDetails);
                  curl_close($curl_customerDetails);
                  $result_customerDetail = json_decode($response_customer);
                  //echo "<pre>";
                  //print_r($result_customerDetail);
                  $custName = "fx:customers";
                  $allCustomerDetails = $result_customerDetail->_embedded->$custName;
                  // echo "<pre>";
                  //  print_r($allCustomerDetails);
                  foreach($allCustomerDetails as $key){
                  $user_id = $key->id;
                  $user_firstName  = $key->first_name;
                  $user_lastName  = $key->last_name;
                  $user_email  = $key->email;
                  $user_password  =$key->password_hash;
                  $chang_pass = md5($user_password);
                  // echo "<pre>";
                   //print_r($user_password);
                   //die();
                  $result_data = array( $user_id,$user_firstName,$user_lastName,$user_email,$user_password);
                  }  
                  // echo "<pre>";
                  // print_r($result_data);
                  
                  //Create user in wordpress after getting email

                  $users = [

                    'users_login' => $user_email,
            
                    'users_pass' => $user_password,
            
                    'user_email' => $user_email,
            
                    'fir_name' => $user_firstName,
            
                    'las_name' => $user_lastName,
            
                    'dis_name' => $user_firstName,
            
                    'role' => 'subscriber',
            
                  ];
            
                  $new_user_id = wp_insert_user( array(
              
                      'user_login' => $users['users_login'],
              
                      'user_pass' => esc_sql($users['users_pass']),
              
                      'user_email' => $users['user_email'],
              
                      'first_name' => $users['fir_name'],
              
                      'last_name' => $users['las_name'],
              
                      'display_name' => $users['dis_name'],
              
                      'role' => $users['role'],
              
                    ));
                    //print_r($new_user_id);
                    add_user_meta($new_user_id, 'foxycart_customer_id', $user_id, true);
                    
                    //wp_update_user(array('ID' => $new_user_id, 'user_pass' => $user_password));
                    //$wpdb->query("UPDATE $wpdb->users SET user_pass = '" . $user_password . "' WHERE ID = $new_user_id");
                
              }
            }
          }
        

  }
  wp_schedule_single_event( time() + 86400, 'api_calling' );
  add_action('parse_request', 'my_custom_url_handler');
  add_shortcode("testing","api_calling");
// if (! defined( 'ABSPATH' ) ) {
//     die;
// }
// defined('ABSPATH') or die('You cannot access this file.');

// class CustomPlugin {
//     function activate(){
//         // generated a CPT
//         // flush rewrite rules
//         $myfile = fopen("../webhook_data.php", "a") or die("Unable to open file!");
//         $txt = "<?php";
//         fwrite($myfile, "\n". $txt);
//         $txt = "require_once('wp-content/plugins/webhook-listener/webhook_add_code.php');";
//         fwrite($myfile, "\n". $txt);
//         fclose($myfile);
//     }
//     function deactivate(){
//         // flush rewrite rules
//         $my_file = '../webhook_data.php';
//         unlink($my_file);
//     }
//     function uninstall(){
//         // delete CPT
//         // delete all the plugin data from the DB
//     }
//     function custom_post_type() {
//         register_post_type('book',['public' => 'true'] );
//     }
// }

// if ( class_exists('CustomPlugin')) {
//     $customPlugin = new CustomPlugin();
// }

// //activation
// register_activation_hook(__FILE__, array($customPlugin,'activate'));

// //deactivation
// register_deactivation_hook(__FILE__, array($customPlugin,'deactivate'));

// //uninstall